# Databricks notebook source
# MAGIC %run ./_common

# COMMAND ----------

DBAcademyHelper().print_copyrights()