-- Databricks notebook source
-- MAGIC %md
-- MAGIC
-- MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
-- MAGIC   <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning">
-- MAGIC </div>
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC # Exploring the Pipeline Events Logs
-- MAGIC
-- MAGIC DLT uses the event logs to store much of the important information used to manage, report, and understand what's happening during pipeline execution.
-- MAGIC
-- MAGIC DLT stores log information in a special table called the `event_log`. To access log data from this table, you must use the **`event_log`** table valued function (TVF). We will use this function in the cells that follow, passing the  pipeline id as a parameter.
-- MAGIC
-- MAGIC Below, we provide a number of useful queries to explore the event log and gain greater insight into your DLT pipelines.
-- MAGIC
-- MAGIC Run the setup script below to get started.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## (REQUIRED!) Please Change to to Serverless Compute!
-- MAGIC The rest of the cells in this notebook must be run with either a serverless cluster, a classic cluster that is in shared access mode, or a SQL warehouse.
-- MAGIC
-- MAGIC **TO DO:** Please select the compute drop down at the top right of the page and select the **Serverless** compute cluster prior to running the cells in this notebook. If you do not select **Serverless** compute you will not be able to complete this demo.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## A. Classroom Setup
-- MAGIC
-- MAGIC Run the following cell to configure your working environment for this course. It will also set your default catalog to **dbacademy** and the schema to your specific schema name shown below using the `USE` statements.
-- MAGIC <br></br>
-- MAGIC ```
-- MAGIC USE CATALOG dbacademy;
-- MAGIC USE SCHEMA dbacademy.<your unique schema name>;
-- MAGIC ```
-- MAGIC
-- MAGIC **NOTE:** The **DA** object is only used in Databricks Academy courses and is not available outside of these courses.

-- COMMAND ----------

-- MAGIC %run ./Includes/Classroom-Setup-5

-- COMMAND ----------

-- MAGIC %md
-- MAGIC **NOTES:** 
-- MAGIC - If you have not completed the DLT pipeline from the previous steps (**1a, 1b, and 1c**), uncomment and run the following cell to create the pipeline using the solution SQL notebooks to complete this demonstration. Wait a few minutes for the DLT pipeline to complete execution.
-- MAGIC - If you have not completed demo **3 - Delta Live Tables Running Modes**, your numbers might not match, but you can still continue with the demonstration.

-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC # DA.generate_pipeline(
-- MAGIC #     pipeline_name=DA.generate_pipeline_name(), 
-- MAGIC #     use_schema = DA.schema_name,
-- MAGIC #     notebooks_folder='2A - SQL Pipelines/(Solutions) 2A - SQL Pipelines', 
-- MAGIC #     pipeline_notebooks=[
-- MAGIC #         '1 - Orders Pipeline',
-- MAGIC #         '2 - Customers Pipeline',
-- MAGIC #         '3L - Status Pipeline Lab'
-- MAGIC #         ],
-- MAGIC #     use_configuration = {'source':f'{DA.paths.stream_source}'}
-- MAGIC #     )
-- MAGIC
-- MAGIC
-- MAGIC # DA.start_pipeline()

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### A1. Generate Required Query
-- MAGIC Run the next cell to generate a query we will need a few minutes.

-- COMMAND ----------

-- MAGIC %python
-- MAGIC DA.print_event_query()

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## B. Important -- Please Read!
-- MAGIC The rest of the cells in this notebook must be run with either a serverless cluster, a classic cluster that is in **shared** access mode, or a SQL warehouse.
-- MAGIC
-- MAGIC **We will be using a Serverless cluster in this lab.** Serverless clusters provide instant, elastic compute for Python and SQL workloads — decoupled from storage — and will automatically scale to provide unlimited concurrency without disruption, for high concurrency use cases.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B1. Query Event Log
-- MAGIC The event log is managed as a Delta Lake table with some of the more important fields stored as nested JSON data.
-- MAGIC
-- MAGIC **REQUIRED:** Copy the query from the previous code cell's output into the next cell, and run the code. This establishes a view into the pipeline event log, showing how simple it is to read the event log table.

-- COMMAND ----------

-- Copy the query from the previous code cell's output into this cell.
-- This cell must be run on a shared cluster, Serverless cluster, or SQL warehouse.
-- In this course we will use a Serverless cluster.
CREATE OR REPLACE VIEW pipeline_event_log AS SELECT * FROM event_log('880395e0-03c3-4313-b70d-38d7e815b6a4');

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Now let's query the view to see the contents of the event log table.

-- COMMAND ----------

SELECT * 
FROM pipeline_event_log

-- COMMAND ----------

-- MAGIC %md
-- MAGIC The query in the previous cell uses the [**`event_log`** table-valued function](https://docs.databricks.com/en/sql/language-manual/functions/event_log.html). This is a built in function that allows you to query the event log for materialized views, streaming tables, and DLT pipelines.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B2. Perform Audit Logging
-- MAGIC
-- MAGIC Events related to running pipelines and editing configurations are captured as **`user_action`**.
-- MAGIC
-- MAGIC Yours should be the only **`user_name`** for the pipeline you configured during this lesson.

-- COMMAND ----------

SELECT 
  timestamp, 
  details:user_action:action, 
  details:user_action:user_name
FROM pipeline_event_log
WHERE event_type = 'user_action'

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B3. Get Latest Update ID
-- MAGIC
-- MAGIC In many cases, you may wish to get information about the latest update to your pipeline.
-- MAGIC
-- MAGIC We can easily capture the most recent update ID with a SQL query.

-- COMMAND ----------

-- Create an SQL STRING variable named latest_updated_id
DECLARE OR REPLACE VARIABLE latest_update_id STRING;

-- Populate the new SQL variable with the latest update ID
SET VARIABLE latest_update_id = (
    SELECT origin.update_id
    FROM pipeline_event_log
    WHERE event_type = 'create_update'
    ORDER BY timestamp DESC LIMIT 1
);

-- View the value of latest_update_id
SELECT latest_update_id

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B4. Examine Lineage
-- MAGIC
-- MAGIC DLT provides built-in lineage information for how data flows through your table.
-- MAGIC
-- MAGIC While the query below only indicates the direct predecessors for each table, this information can easily be combined to trace data in any table back to the point it entered the lakehouse.

-- COMMAND ----------

SELECT 
  details:flow_definition.output_dataset, 
  details:flow_definition.input_datasets 
FROM pipeline_event_log
WHERE event_type = 'flow_definition' AND 
      origin.update_id = latest_update_id

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B5. Examine Data Quality Metrics
-- MAGIC
-- MAGIC Finally, data quality metrics can be extremely useful for both long term and short term insights into your data.
-- MAGIC
-- MAGIC Below, we capture the metrics for each constraint throughout the entire lifetime of our table.

-- COMMAND ----------

SELECT 
  row_expectations.dataset as dataset,
  row_expectations.name as expectation,
  SUM(row_expectations.passed_records) as passing_records,
  SUM(row_expectations.failed_records) as failing_records
FROM
  (SELECT explode(
            from_json(details :flow_progress :data_quality :expectations,
                      "array<struct<name: string, dataset: string, passed_records: int, failed_records: int>>")
          ) row_expectations
   FROM pipeline_event_log
   WHERE event_type = 'flow_progress' AND 
         origin.update_id = latest_update_id
  )
GROUP BY row_expectations.dataset, row_expectations.name

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC &copy; 2024 Databricks, Inc. All rights reserved.<br/>
-- MAGIC Apache, Apache Spark, Spark and the Spark logo are trademarks of the 
-- MAGIC <a href="https://www.apache.org/">Apache Software Foundation</a>.<br/>
-- MAGIC <br/><a href="https://databricks.com/privacy-policy">Privacy Policy</a> | 
-- MAGIC <a href="https://databricks.com/terms-of-use">Terms of Use</a> | 
-- MAGIC <a href="https://help.databricks.com/">Support</a>